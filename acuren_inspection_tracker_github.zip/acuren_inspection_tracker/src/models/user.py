# Empty user model file for deployment compatibility

